﻿
namespace gaoxiaoss
{
	partial class menu
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.就业率ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.已就业信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.未就业信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.公司信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelmajorrate = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.labelgraduation = new System.Windows.Forms.Label();
            this.labelprework = new System.Windows.Forms.Label();
            this.labelworked = new System.Windows.Forms.Label();
            this.labelworkrate = new System.Windows.Forms.Label();
            this.labelmajor = new System.Windows.Forms.Label();
            this.textBoxgradnum = new System.Windows.Forms.TextBox();
            this.textBoxpreworknum = new System.Windows.Forms.TextBox();
            this.textBoxworkednum = new System.Windows.Forms.TextBox();
            this.textBoxworkrate = new System.Windows.Forms.TextBox();
            this.textBoxmajorworkedrate = new System.Windows.Forms.TextBox();
            this.comboBoxmajor = new System.Windows.Forms.ComboBox();
            this.buttoncheck = new System.Windows.Forms.Button();
            this.paneljiuye = new System.Windows.Forms.Panel();
            this.panelprework = new System.Windows.Forms.Panel();
            this.dataGridViewprework = new System.Windows.Forms.DataGridView();
            this.buttonmajor1 = new System.Windows.Forms.Button();
            this.buttoncollege1 = new System.Windows.Forms.Button();
            this.comboBoxprecollege = new System.Windows.Forms.ComboBox();
            this.comboBoxmajor1 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panelcompany = new System.Windows.Forms.Panel();
            this.dataGridViewcompany = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.panelchange = new System.Windows.Forms.Panel();
            this.groupBoxchange = new System.Windows.Forms.GroupBox();
            this.buttonchangebasedinfo = new System.Windows.Forms.Button();
            this.buttonchangejobinfo = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButtongirl = new System.Windows.Forms.RadioButton();
            this.radioButtonboy = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonworked = new System.Windows.Forms.RadioButton();
            this.radioButtonprework = new System.Windows.Forms.RadioButton();
            this.buttonadd = new System.Windows.Forms.Button();
            this.comboBoxschool = new System.Windows.Forms.ComboBox();
            this.comboBoxtype = new System.Windows.Forms.ComboBox();
            this.comboBoxcomcompany = new System.Windows.Forms.ComboBox();
            this.comboBoxMajr = new System.Windows.Forms.ComboBox();
            this.textBoxbirth = new System.Windows.Forms.TextBox();
            this.textBoxname = new System.Windows.Forms.TextBox();
            this.textBoxhome = new System.Windows.Forms.TextBox();
            this.textBoxid = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelworked = new System.Windows.Forms.Panel();
            this.dataGridViewworked = new System.Windows.Forms.DataGridView();
            this.buttonmajor = new System.Windows.Forms.Button();
            this.buttoncollege = new System.Windows.Forms.Button();
            this.comboBoxcollege = new System.Windows.Forms.ComboBox();
            this.comboBoxmajo = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.menuStrip1.SuspendLayout();
            this.paneljiuye.SuspendLayout();
            this.panelprework.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewprework)).BeginInit();
            this.panelcompany.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewcompany)).BeginInit();
            this.panelchange.SuspendLayout();
            this.groupBoxchange.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panelworked.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewworked)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改ToolStripMenuItem,
            this.查询ToolStripMenuItem,
            this.添加ToolStripMenuItem,
            this.退出ToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(609, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 修改ToolStripMenuItem
            // 
            this.修改ToolStripMenuItem.Name = "修改ToolStripMenuItem";
            this.修改ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.修改ToolStripMenuItem.Text = "修改";
            this.修改ToolStripMenuItem.Click += new System.EventHandler(this.修改ToolStripMenuItemClick);
            // 
            // 查询ToolStripMenuItem
            // 
            this.查询ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.就业率ToolStripMenuItem,
            this.已就业信息ToolStripMenuItem,
            this.未就业信息ToolStripMenuItem,
            this.公司信息ToolStripMenuItem});
            this.查询ToolStripMenuItem.Name = "查询ToolStripMenuItem";
            this.查询ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.查询ToolStripMenuItem.Text = "查询";
            this.查询ToolStripMenuItem.Click += new System.EventHandler(this.查询ToolStripMenuItemClick);
            // 
            // 就业率ToolStripMenuItem
            // 
            this.就业率ToolStripMenuItem.Name = "就业率ToolStripMenuItem";
            this.就业率ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.就业率ToolStripMenuItem.Text = "就业率";
            this.就业率ToolStripMenuItem.Click += new System.EventHandler(this.就业率ToolStripMenuItemClick);
            // 
            // 已就业信息ToolStripMenuItem
            // 
            this.已就业信息ToolStripMenuItem.Name = "已就业信息ToolStripMenuItem";
            this.已就业信息ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.已就业信息ToolStripMenuItem.Text = "已就业信息";
            this.已就业信息ToolStripMenuItem.Click += new System.EventHandler(this.已就业信息ToolStripMenuItemClick);
            // 
            // 未就业信息ToolStripMenuItem
            // 
            this.未就业信息ToolStripMenuItem.Name = "未就业信息ToolStripMenuItem";
            this.未就业信息ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.未就业信息ToolStripMenuItem.Text = "未就业信息";
            this.未就业信息ToolStripMenuItem.Click += new System.EventHandler(this.未就业信息ToolStripMenuItemClick);
            // 
            // 公司信息ToolStripMenuItem
            // 
            this.公司信息ToolStripMenuItem.Name = "公司信息ToolStripMenuItem";
            this.公司信息ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.公司信息ToolStripMenuItem.Text = "公司信息";
            this.公司信息ToolStripMenuItem.Click += new System.EventHandler(this.公司信息ToolStripMenuItemClick);
            // 
            // 添加ToolStripMenuItem
            // 
            this.添加ToolStripMenuItem.Name = "添加ToolStripMenuItem";
            this.添加ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.添加ToolStripMenuItem.Text = "添加";
            this.添加ToolStripMenuItem.Click += new System.EventHandler(this.添加ToolStripMenuItemClick);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.toolStripComboBox1});
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItemClick);
            // 
            // labelmajorrate
            // 
            this.labelmajorrate.Location = new System.Drawing.Point(2, 191);
            this.labelmajorrate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelmajorrate.Name = "labelmajorrate";
            this.labelmajorrate.Size = new System.Drawing.Size(98, 26);
            this.labelmajorrate.TabIndex = 1;
            this.labelmajorrate.Text = "专业方向就业率";
            this.labelmajorrate.Click += new System.EventHandler(this.LabelmajorrateClick);
            // 
            // labelgraduation
            // 
            this.labelgraduation.Location = new System.Drawing.Point(7, 3);
            this.labelgraduation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelgraduation.Name = "labelgraduation";
            this.labelgraduation.Size = new System.Drawing.Size(86, 26);
            this.labelgraduation.TabIndex = 1;
            this.labelgraduation.Text = "毕业生人数";
            // 
            // labelprework
            // 
            this.labelprework.Location = new System.Drawing.Point(7, 46);
            this.labelprework.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelprework.Name = "labelprework";
            this.labelprework.Size = new System.Drawing.Size(86, 26);
            this.labelprework.TabIndex = 1;
            this.labelprework.Text = "待就业人数";
            // 
            // labelworked
            // 
            this.labelworked.Location = new System.Drawing.Point(7, 82);
            this.labelworked.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelworked.Name = "labelworked";
            this.labelworked.Size = new System.Drawing.Size(86, 26);
            this.labelworked.TabIndex = 1;
            this.labelworked.Text = "就业人数";
            // 
            // labelworkrate
            // 
            this.labelworkrate.Location = new System.Drawing.Point(7, 122);
            this.labelworkrate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelworkrate.Name = "labelworkrate";
            this.labelworkrate.Size = new System.Drawing.Size(86, 26);
            this.labelworkrate.TabIndex = 1;
            this.labelworkrate.Text = "就业率";
            // 
            // labelmajor
            // 
            this.labelmajor.Location = new System.Drawing.Point(7, 159);
            this.labelmajor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelmajor.Name = "labelmajor";
            this.labelmajor.Size = new System.Drawing.Size(86, 26);
            this.labelmajor.TabIndex = 1;
            this.labelmajor.Text = "专业方向";
            // 
            // textBoxgradnum
            // 
            this.textBoxgradnum.Location = new System.Drawing.Point(104, 3);
            this.textBoxgradnum.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxgradnum.Name = "textBoxgradnum";
            this.textBoxgradnum.Size = new System.Drawing.Size(242, 21);
            this.textBoxgradnum.TabIndex = 2;
            // 
            // textBoxpreworknum
            // 
            this.textBoxpreworknum.Location = new System.Drawing.Point(104, 44);
            this.textBoxpreworknum.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxpreworknum.Name = "textBoxpreworknum";
            this.textBoxpreworknum.Size = new System.Drawing.Size(242, 21);
            this.textBoxpreworknum.TabIndex = 2;
            // 
            // textBoxworkednum
            // 
            this.textBoxworkednum.Location = new System.Drawing.Point(104, 80);
            this.textBoxworkednum.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxworkednum.Name = "textBoxworkednum";
            this.textBoxworkednum.Size = new System.Drawing.Size(242, 21);
            this.textBoxworkednum.TabIndex = 2;
            // 
            // textBoxworkrate
            // 
            this.textBoxworkrate.Location = new System.Drawing.Point(104, 119);
            this.textBoxworkrate.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxworkrate.Name = "textBoxworkrate";
            this.textBoxworkrate.Size = new System.Drawing.Size(242, 21);
            this.textBoxworkrate.TabIndex = 2;
            // 
            // textBoxmajorworkedrate
            // 
            this.textBoxmajorworkedrate.Location = new System.Drawing.Point(104, 191);
            this.textBoxmajorworkedrate.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxmajorworkedrate.Name = "textBoxmajorworkedrate";
            this.textBoxmajorworkedrate.Size = new System.Drawing.Size(134, 21);
            this.textBoxmajorworkedrate.TabIndex = 2;
            // 
            // comboBoxmajor
            // 
            this.comboBoxmajor.FormattingEnabled = true;
            this.comboBoxmajor.Location = new System.Drawing.Point(104, 157);
            this.comboBoxmajor.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxmajor.Name = "comboBoxmajor";
            this.comboBoxmajor.Size = new System.Drawing.Size(168, 20);
            this.comboBoxmajor.TabIndex = 3;
            // 
            // buttoncheck
            // 
            this.buttoncheck.Location = new System.Drawing.Point(276, 157);
            this.buttoncheck.Margin = new System.Windows.Forms.Padding(2);
            this.buttoncheck.Name = "buttoncheck";
            this.buttoncheck.Size = new System.Drawing.Size(70, 22);
            this.buttoncheck.TabIndex = 4;
            this.buttoncheck.Text = "查询";
            this.buttoncheck.UseVisualStyleBackColor = true;
            this.buttoncheck.Click += new System.EventHandler(this.ButtoncheckClick);
            // 
            // paneljiuye
            // 
            this.paneljiuye.Controls.Add(this.buttoncheck);
            this.paneljiuye.Controls.Add(this.labelmajorrate);
            this.paneljiuye.Controls.Add(this.comboBoxmajor);
            this.paneljiuye.Controls.Add(this.textBoxmajorworkedrate);
            this.paneljiuye.Controls.Add(this.textBoxworkrate);
            this.paneljiuye.Controls.Add(this.textBoxworkednum);
            this.paneljiuye.Controls.Add(this.textBoxpreworknum);
            this.paneljiuye.Controls.Add(this.textBoxgradnum);
            this.paneljiuye.Controls.Add(this.labelmajor);
            this.paneljiuye.Controls.Add(this.labelworkrate);
            this.paneljiuye.Controls.Add(this.labelworked);
            this.paneljiuye.Controls.Add(this.labelprework);
            this.paneljiuye.Controls.Add(this.labelgraduation);
            this.paneljiuye.Location = new System.Drawing.Point(70, 35);
            this.paneljiuye.Margin = new System.Windows.Forms.Padding(2);
            this.paneljiuye.Name = "paneljiuye";
            this.paneljiuye.Size = new System.Drawing.Size(460, 333);
            this.paneljiuye.TabIndex = 5;
            this.paneljiuye.Visible = false;
            this.paneljiuye.Paint += new System.Windows.Forms.PaintEventHandler(this.PaneljiuyePaint);
            // 
            // panelprework
            // 
            this.panelprework.Controls.Add(this.dataGridViewprework);
            this.panelprework.Controls.Add(this.buttonmajor1);
            this.panelprework.Controls.Add(this.buttoncollege1);
            this.panelprework.Controls.Add(this.comboBoxprecollege);
            this.panelprework.Controls.Add(this.comboBoxmajor1);
            this.panelprework.Controls.Add(this.label13);
            this.panelprework.Controls.Add(this.label14);
            this.panelprework.Location = new System.Drawing.Point(70, 36);
            this.panelprework.Margin = new System.Windows.Forms.Padding(2);
            this.panelprework.Name = "panelprework";
            this.panelprework.Size = new System.Drawing.Size(460, 332);
            this.panelprework.TabIndex = 17;
            this.panelprework.Visible = false;
            this.panelprework.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelpreworkPaint);
            // 
            // dataGridViewprework
            // 
            this.dataGridViewprework.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewprework.Location = new System.Drawing.Point(17, 83);
            this.dataGridViewprework.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewprework.Name = "dataGridViewprework";
            this.dataGridViewprework.RowTemplate.Height = 27;
            this.dataGridViewprework.Size = new System.Drawing.Size(415, 229);
            this.dataGridViewprework.TabIndex = 15;
            this.dataGridViewprework.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewpreworkCellContentClick);
            // 
            // buttonmajor1
            // 
            this.buttonmajor1.Location = new System.Drawing.Point(332, 53);
            this.buttonmajor1.Margin = new System.Windows.Forms.Padding(2);
            this.buttonmajor1.Name = "buttonmajor1";
            this.buttonmajor1.Size = new System.Drawing.Size(64, 26);
            this.buttonmajor1.TabIndex = 14;
            this.buttonmajor1.Text = "确定";
            this.buttonmajor1.UseVisualStyleBackColor = true;
            this.buttonmajor1.Click += new System.EventHandler(this.Buttonmajor1Click);
            // 
            // buttoncollege1
            // 
            this.buttoncollege1.Location = new System.Drawing.Point(332, 14);
            this.buttoncollege1.Margin = new System.Windows.Forms.Padding(2);
            this.buttoncollege1.Name = "buttoncollege1";
            this.buttoncollege1.Size = new System.Drawing.Size(64, 26);
            this.buttoncollege1.TabIndex = 14;
            this.buttoncollege1.Text = "确定";
            this.buttoncollege1.UseVisualStyleBackColor = true;
            this.buttoncollege1.Click += new System.EventHandler(this.Buttoncollege1Click);
            // 
            // comboBoxprecollege
            // 
            this.comboBoxprecollege.FormattingEnabled = true;
            this.comboBoxprecollege.Location = new System.Drawing.Point(92, 14);
            this.comboBoxprecollege.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxprecollege.Name = "comboBoxprecollege";
            this.comboBoxprecollege.Size = new System.Drawing.Size(223, 20);
            this.comboBoxprecollege.TabIndex = 13;
            this.comboBoxprecollege.SelectedIndexChanged += new System.EventHandler(this.ComboBoxprecollegeSelectedIndexChanged);
            // 
            // comboBoxmajor1
            // 
            this.comboBoxmajor1.FormattingEnabled = true;
            this.comboBoxmajor1.Location = new System.Drawing.Point(92, 60);
            this.comboBoxmajor1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxmajor1.Name = "comboBoxmajor1";
            this.comboBoxmajor1.Size = new System.Drawing.Size(223, 20);
            this.comboBoxmajor1.TabIndex = 13;
            this.comboBoxmajor1.SelectedIndexChanged += new System.EventHandler(this.ComboBoxmajor1SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(49, 62);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(107, 30);
            this.label13.TabIndex = 12;
            this.label13.Text = "专业";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(49, 17);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(107, 30);
            this.label14.TabIndex = 12;
            this.label14.Text = "学院";
            // 
            // panelcompany
            // 
            this.panelcompany.Controls.Add(this.dataGridViewcompany);
            this.panelcompany.Controls.Add(this.label15);
            this.panelcompany.Location = new System.Drawing.Point(70, 35);
            this.panelcompany.Margin = new System.Windows.Forms.Padding(2);
            this.panelcompany.Name = "panelcompany";
            this.panelcompany.Size = new System.Drawing.Size(460, 333);
            this.panelcompany.TabIndex = 20;
            this.panelcompany.Visible = false;
            // 
            // dataGridViewcompany
            // 
            this.dataGridViewcompany.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewcompany.Location = new System.Drawing.Point(35, 59);
            this.dataGridViewcompany.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewcompany.Name = "dataGridViewcompany";
            this.dataGridViewcompany.RowTemplate.Height = 27;
            this.dataGridViewcompany.Size = new System.Drawing.Size(332, 249);
            this.dataGridViewcompany.TabIndex = 19;
            this.dataGridViewcompany.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewcompanyCellContentClick);
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("宋体", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(100, 17);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(238, 39);
            this.label15.TabIndex = 18;
            this.label15.Text = "来校公司信息";
            // 
            // panelchange
            // 
            this.panelchange.Controls.Add(this.groupBoxchange);
            this.panelchange.Controls.Add(this.groupBox2);
            this.panelchange.Controls.Add(this.groupBox1);
            this.panelchange.Controls.Add(this.buttonadd);
            this.panelchange.Controls.Add(this.comboBoxschool);
            this.panelchange.Controls.Add(this.comboBoxtype);
            this.panelchange.Controls.Add(this.comboBoxcomcompany);
            this.panelchange.Controls.Add(this.comboBoxMajr);
            this.panelchange.Controls.Add(this.textBoxbirth);
            this.panelchange.Controls.Add(this.textBoxname);
            this.panelchange.Controls.Add(this.textBoxhome);
            this.panelchange.Controls.Add(this.textBoxid);
            this.panelchange.Controls.Add(this.label7);
            this.panelchange.Controls.Add(this.label6);
            this.panelchange.Controls.Add(this.label3);
            this.panelchange.Controls.Add(this.label5);
            this.panelchange.Controls.Add(this.label4);
            this.panelchange.Controls.Add(this.label2);
            this.panelchange.Controls.Add(this.label10);
            this.panelchange.Controls.Add(this.label9);
            this.panelchange.Controls.Add(this.label8);
            this.panelchange.Controls.Add(this.label1);
            this.panelchange.Location = new System.Drawing.Point(70, 37);
            this.panelchange.Margin = new System.Windows.Forms.Padding(2);
            this.panelchange.Name = "panelchange";
            this.panelchange.Size = new System.Drawing.Size(460, 331);
            this.panelchange.TabIndex = 11;
            this.panelchange.Visible = false;
            this.panelchange.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelchangePaint);
            // 
            // groupBoxchange
            // 
            this.groupBoxchange.Controls.Add(this.buttonchangebasedinfo);
            this.groupBoxchange.Controls.Add(this.buttonchangejobinfo);
            this.groupBoxchange.Location = new System.Drawing.Point(49, 266);
            this.groupBoxchange.Margin = new System.Windows.Forms.Padding(2);
            this.groupBoxchange.Name = "groupBoxchange";
            this.groupBoxchange.Padding = new System.Windows.Forms.Padding(2);
            this.groupBoxchange.Size = new System.Drawing.Size(313, 49);
            this.groupBoxchange.TabIndex = 14;
            this.groupBoxchange.TabStop = false;
            // 
            // buttonchangebasedinfo
            // 
            this.buttonchangebasedinfo.Location = new System.Drawing.Point(180, 13);
            this.buttonchangebasedinfo.Margin = new System.Windows.Forms.Padding(2);
            this.buttonchangebasedinfo.Name = "buttonchangebasedinfo";
            this.buttonchangebasedinfo.Size = new System.Drawing.Size(113, 29);
            this.buttonchangebasedinfo.TabIndex = 7;
            this.buttonchangebasedinfo.Text = "修改基本信息";
            this.buttonchangebasedinfo.UseVisualStyleBackColor = true;
            this.buttonchangebasedinfo.Click += new System.EventHandler(this.ButtonchangebasedinfoClick);
            // 
            // buttonchangejobinfo
            // 
            this.buttonchangejobinfo.Location = new System.Drawing.Point(28, 12);
            this.buttonchangejobinfo.Margin = new System.Windows.Forms.Padding(2);
            this.buttonchangejobinfo.Name = "buttonchangejobinfo";
            this.buttonchangejobinfo.Size = new System.Drawing.Size(113, 29);
            this.buttonchangejobinfo.TabIndex = 7;
            this.buttonchangejobinfo.Text = "修改就业信息";
            this.buttonchangejobinfo.UseVisualStyleBackColor = true;
            this.buttonchangejobinfo.Click += new System.EventHandler(this.ButtonchangejobinfoClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtongirl);
            this.groupBox2.Controls.Add(this.radioButtonboy);
            this.groupBox2.Location = new System.Drawing.Point(58, 40);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(115, 32);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.GroupBox2Enter);
            // 
            // radioButtongirl
            // 
            this.radioButtongirl.Location = new System.Drawing.Point(81, 10);
            this.radioButtongirl.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtongirl.Name = "radioButtongirl";
            this.radioButtongirl.Size = new System.Drawing.Size(34, 19);
            this.radioButtongirl.TabIndex = 10;
            this.radioButtongirl.TabStop = true;
            this.radioButtongirl.Text = "女";
            this.radioButtongirl.UseVisualStyleBackColor = true;
            this.radioButtongirl.CheckedChanged += new System.EventHandler(this.RadioButtongirlCheckedChanged);
            // 
            // radioButtonboy
            // 
            this.radioButtonboy.Location = new System.Drawing.Point(8, 10);
            this.radioButtonboy.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonboy.Name = "radioButtonboy";
            this.radioButtonboy.Size = new System.Drawing.Size(34, 19);
            this.radioButtonboy.TabIndex = 10;
            this.radioButtonboy.TabStop = true;
            this.radioButtonboy.Text = "男";
            this.radioButtonboy.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonworked);
            this.groupBox1.Controls.Add(this.radioButtonprework);
            this.groupBox1.Location = new System.Drawing.Point(63, 159);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(152, 25);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // radioButtonworked
            // 
            this.radioButtonworked.Location = new System.Drawing.Point(74, 2);
            this.radioButtonworked.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonworked.Name = "radioButtonworked";
            this.radioButtonworked.Size = new System.Drawing.Size(59, 19);
            this.radioButtonworked.TabIndex = 10;
            this.radioButtonworked.TabStop = true;
            this.radioButtonworked.Text = "已就业";
            this.radioButtonworked.UseVisualStyleBackColor = true;
            // 
            // radioButtonprework
            // 
            this.radioButtonprework.Location = new System.Drawing.Point(4, 2);
            this.radioButtonprework.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonprework.Name = "radioButtonprework";
            this.radioButtonprework.Size = new System.Drawing.Size(66, 19);
            this.radioButtonprework.TabIndex = 10;
            this.radioButtonprework.TabStop = true;
            this.radioButtonprework.Text = "待就业";
            this.radioButtonprework.UseVisualStyleBackColor = true;
            // 
            // buttonadd
            // 
            this.buttonadd.Location = new System.Drawing.Point(229, 223);
            this.buttonadd.Margin = new System.Windows.Forms.Padding(2);
            this.buttonadd.Name = "buttonadd";
            this.buttonadd.Size = new System.Drawing.Size(113, 33);
            this.buttonadd.TabIndex = 11;
            this.buttonadd.Text = "添加";
            this.buttonadd.UseVisualStyleBackColor = true;
            this.buttonadd.Visible = false;
            this.buttonadd.Click += new System.EventHandler(this.Button1Click);
            // 
            // comboBoxschool
            // 
            this.comboBoxschool.FormattingEnabled = true;
            this.comboBoxschool.Location = new System.Drawing.Point(277, 121);
            this.comboBoxschool.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxschool.Name = "comboBoxschool";
            this.comboBoxschool.Size = new System.Drawing.Size(140, 20);
            this.comboBoxschool.TabIndex = 9;
            // 
            // comboBoxtype
            // 
            this.comboBoxtype.FormattingEnabled = true;
            this.comboBoxtype.Location = new System.Drawing.Point(67, 238);
            this.comboBoxtype.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxtype.Name = "comboBoxtype";
            this.comboBoxtype.Size = new System.Drawing.Size(140, 20);
            this.comboBoxtype.TabIndex = 9;
            this.comboBoxtype.SelectedIndexChanged += new System.EventHandler(this.ComboBoxtypeSelectedIndexChanged);
            // 
            // comboBoxcomcompany
            // 
            this.comboBoxcomcompany.FormattingEnabled = true;
            this.comboBoxcomcompany.Location = new System.Drawing.Point(67, 201);
            this.comboBoxcomcompany.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxcomcompany.Name = "comboBoxcomcompany";
            this.comboBoxcomcompany.Size = new System.Drawing.Size(140, 20);
            this.comboBoxcomcompany.TabIndex = 9;
            // 
            // comboBoxMajr
            // 
            this.comboBoxMajr.FormattingEnabled = true;
            this.comboBoxMajr.Location = new System.Drawing.Point(67, 121);
            this.comboBoxMajr.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxMajr.Name = "comboBoxMajr";
            this.comboBoxMajr.Size = new System.Drawing.Size(140, 20);
            this.comboBoxMajr.TabIndex = 9;
            // 
            // textBoxbirth
            // 
            this.textBoxbirth.Location = new System.Drawing.Point(277, 40);
            this.textBoxbirth.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxbirth.Name = "textBoxbirth";
            this.textBoxbirth.Size = new System.Drawing.Size(108, 21);
            this.textBoxbirth.TabIndex = 8;
            // 
            // textBoxname
            // 
            this.textBoxname.Location = new System.Drawing.Point(277, 2);
            this.textBoxname.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxname.Name = "textBoxname";
            this.textBoxname.Size = new System.Drawing.Size(108, 21);
            this.textBoxname.TabIndex = 8;
            this.textBoxname.TextChanged += new System.EventHandler(this.TextBox2TextChanged);
            // 
            // textBoxhome
            // 
            this.textBoxhome.Location = new System.Drawing.Point(67, 81);
            this.textBoxhome.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxhome.Name = "textBoxhome";
            this.textBoxhome.Size = new System.Drawing.Size(261, 21);
            this.textBoxhome.TabIndex = 8;
            // 
            // textBoxid
            // 
            this.textBoxid.Location = new System.Drawing.Point(67, 2);
            this.textBoxid.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxid.Name = "textBoxid";
            this.textBoxid.Size = new System.Drawing.Size(108, 21);
            this.textBoxid.TabIndex = 8;
            this.textBoxid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxidKeyPress);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(11, 241);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "类型名称";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(11, 202);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "用人单位";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(11, 86);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "籍贯";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(11, 162);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "就业情况";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(11, 124);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "专业";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(11, 45);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "性别";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(214, 124);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 15);
            this.label10.TabIndex = 6;
            this.label10.Text = "学院名称";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(214, 45);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 15);
            this.label9.TabIndex = 6;
            this.label9.Text = "出生年月";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(214, 7);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 15);
            this.label8.TabIndex = 6;
            this.label8.Text = "姓名";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(11, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "学号";
            // 
            // panelworked
            // 
            this.panelworked.Controls.Add(this.dataGridViewworked);
            this.panelworked.Controls.Add(this.buttonmajor);
            this.panelworked.Controls.Add(this.buttoncollege);
            this.panelworked.Controls.Add(this.comboBoxcollege);
            this.panelworked.Controls.Add(this.comboBoxmajo);
            this.panelworked.Controls.Add(this.label12);
            this.panelworked.Controls.Add(this.label11);
            this.panelworked.Location = new System.Drawing.Point(70, 35);
            this.panelworked.Margin = new System.Windows.Forms.Padding(2);
            this.panelworked.Name = "panelworked";
            this.panelworked.Size = new System.Drawing.Size(460, 333);
            this.panelworked.TabIndex = 16;
            this.panelworked.Visible = false;
            this.panelworked.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelworkedPaint);
            // 
            // dataGridViewworked
            // 
            this.dataGridViewworked.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewworked.Location = new System.Drawing.Point(17, 83);
            this.dataGridViewworked.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewworked.Name = "dataGridViewworked";
            this.dataGridViewworked.RowTemplate.Height = 27;
            this.dataGridViewworked.Size = new System.Drawing.Size(415, 229);
            this.dataGridViewworked.TabIndex = 15;
            this.dataGridViewworked.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewworkedCellContentClick);
            // 
            // buttonmajor
            // 
            this.buttonmajor.Location = new System.Drawing.Point(332, 53);
            this.buttonmajor.Margin = new System.Windows.Forms.Padding(2);
            this.buttonmajor.Name = "buttonmajor";
            this.buttonmajor.Size = new System.Drawing.Size(64, 26);
            this.buttonmajor.TabIndex = 14;
            this.buttonmajor.Text = "确定";
            this.buttonmajor.UseVisualStyleBackColor = true;
            this.buttonmajor.Click += new System.EventHandler(this.ButtonmajorClick);
            // 
            // buttoncollege
            // 
            this.buttoncollege.Location = new System.Drawing.Point(332, 14);
            this.buttoncollege.Margin = new System.Windows.Forms.Padding(2);
            this.buttoncollege.Name = "buttoncollege";
            this.buttoncollege.Size = new System.Drawing.Size(64, 26);
            this.buttoncollege.TabIndex = 14;
            this.buttoncollege.Text = "确定";
            this.buttoncollege.UseVisualStyleBackColor = true;
            this.buttoncollege.Click += new System.EventHandler(this.ButtoncollegeClick);
            // 
            // comboBoxcollege
            // 
            this.comboBoxcollege.FormattingEnabled = true;
            this.comboBoxcollege.Location = new System.Drawing.Point(92, 14);
            this.comboBoxcollege.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxcollege.Name = "comboBoxcollege";
            this.comboBoxcollege.Size = new System.Drawing.Size(223, 20);
            this.comboBoxcollege.TabIndex = 13;
            // 
            // comboBoxmajo
            // 
            this.comboBoxmajo.FormattingEnabled = true;
            this.comboBoxmajo.Location = new System.Drawing.Point(92, 60);
            this.comboBoxmajo.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxmajo.Name = "comboBoxmajo";
            this.comboBoxmajo.Size = new System.Drawing.Size(223, 20);
            this.comboBoxmajo.TabIndex = 13;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(49, 62);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(107, 30);
            this.label12.TabIndex = 12;
            this.label12.Text = "专业";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(49, 17);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 30);
            this.label11.TabIndex = 12;
            this.label11.Text = "学院";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(41, 21);
            this.toolStripMenuItem1.Text = "123";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(178, 6);
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 25);
            // 
            // menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 378);
            this.Controls.Add(this.panelprework);
            this.Controls.Add(this.panelcompany);
            this.Controls.Add(this.panelworked);
            this.Controls.Add(this.paneljiuye);
            this.Controls.Add(this.panelchange);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "menu";
            this.Text = "高校学生就业管理系统";
            this.Load += new System.EventHandler(this.MenuLoad);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.paneljiuye.ResumeLayout(false);
            this.paneljiuye.PerformLayout();
            this.panelprework.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewprework)).EndInit();
            this.panelcompany.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewcompany)).EndInit();
            this.panelchange.ResumeLayout(false);
            this.panelchange.PerformLayout();
            this.groupBoxchange.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panelworked.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewworked)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.GroupBox groupBoxchange;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button buttonadd;
		private System.Windows.Forms.Panel panelcompany;
		private System.Windows.Forms.DataGridView dataGridViewcompany;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.ComboBox comboBoxmajor1;
		private System.Windows.Forms.ComboBox comboBoxprecollege;
		private System.Windows.Forms.Button buttoncollege1;
		private System.Windows.Forms.Button buttonmajor1;
		private System.Windows.Forms.DataGridView dataGridViewprework;
		private System.Windows.Forms.Panel panelprework;
		private System.Windows.Forms.Panel panelworked;
		private System.Windows.Forms.DataGridView dataGridViewworked;
		private System.Windows.Forms.Button buttonmajor;
		private System.Windows.Forms.Button buttoncollege;
		private System.Windows.Forms.ComboBox comboBoxcollege;
		private System.Windows.Forms.ComboBox comboBoxmajo;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Panel panelchange;
		private System.Windows.Forms.RadioButton radioButtonworked;
		private System.Windows.Forms.RadioButton radioButtonprework;
		private System.Windows.Forms.RadioButton radioButtongirl;
		private System.Windows.Forms.RadioButton radioButtonboy;
		private System.Windows.Forms.ComboBox comboBoxtype;
		private System.Windows.Forms.ComboBox comboBoxcomcompany;
		private System.Windows.Forms.ComboBox comboBoxschool;
		private System.Windows.Forms.ComboBox comboBoxMajr;
		private System.Windows.Forms.TextBox textBoxhome;
		private System.Windows.Forms.TextBox textBoxbirth;
		private System.Windows.Forms.TextBox textBoxname;
		private System.Windows.Forms.TextBox textBoxid;
		private System.Windows.Forms.Button buttonchangebasedinfo;
		private System.Windows.Forms.Button buttonchangejobinfo;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel paneljiuye;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.Button buttoncheck;
		private System.Windows.Forms.ComboBox comboBoxmajor;
		private System.Windows.Forms.TextBox textBoxmajorworkedrate;
		private System.Windows.Forms.TextBox textBoxworkrate;
		private System.Windows.Forms.TextBox textBoxworkednum;
		private System.Windows.Forms.TextBox textBoxpreworknum;
		private System.Windows.Forms.TextBox textBoxgradnum;
		private System.Windows.Forms.Label labelmajorrate;
		private System.Windows.Forms.Label labelmajor;
		private System.Windows.Forms.Label labelworkrate;
		private System.Windows.Forms.Label labelworked;
		private System.Windows.Forms.Label labelprework;
		private System.Windows.Forms.Label labelgraduation;
		private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 添加ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 公司信息ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 未就业信息ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 已就业信息ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 就业率ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 查询ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 修改ToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
    }
}
