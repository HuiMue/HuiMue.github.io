﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace gaoxiaoss
{
	/// <summary>
	/// Class with program entry point.
	/// </summary>
	internal sealed class Program
	{
		/// <summary>
		/// Program entry point.
		/// </summary>
		//[STAThread]
		public static string peocontact = @"data source =LAPTOP-9ULLRPDJ;initial catalog =StudentsEmployment;integrated security=true";
		public SqlConnection con = new SqlConnection(peocontact);
		private static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new MainForm());
		}
		public void getConn()
		{

			try {
				con.Open();
			}
			catch (Exception e)
			{
				MessageBox.Show("数据库连接错误");
				Application.Exit();
			}
		}
		public int GetCountInfoBySql(string s)
		{
			    SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText=s;
                SqlDataAdapter sda=new SqlDataAdapter(cmd);
                DataSet dataset=new DataSet();
                sda.Fill(dataset);
                int count = Convert.ToInt32((dataset.Tables[0]).Rows[0][0].ToString());

                return count ;
                //return cmd.ExecuteNonQuery();
		}
		public void UpdateDate(string s)
		{
			    SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText=s;
                 cmd.ExecuteNonQuery();
		}
		public string GetDataString(string s)
		{
			    SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText=s;
                SqlDataAdapter sda=new SqlDataAdapter(cmd);
                DataSet dataset=new DataSet();
                sda.Fill(dataset);
                return (dataset.Tables[0]).Rows[0][0].ToString() ;
		}
		public SqlDataReader GetSqlDataReader(string s)
		{
			    SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText=s;
     			SqlDataReader dr=cmd.ExecuteReader();	
                return dr;
		}
		public DataSet GetDataSuoce(string s)
		{    	SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText=s;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds,"hahah");
           
                return ds;
		}
		public void  CloseConn(){
			
			 con.Close();
		}
	}
}
