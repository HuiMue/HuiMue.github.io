// index.js
Page({
  data:{
    parami: "hello world ", 
    param2: ['a','b','c' ], 
    param3:"red"
  }
})
