// pages/member/member.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    categoryList:['A','B','C','D'],
    activeIndex : 0,
    goodsList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  getGoodsList(e){
    wx.request({
      url:'http://159.75.133.247:8089/store/store/page?currentPage=1&pageSize=5&groupName=zy&busiType=goods&subType='+e,
      method:'GET',
      success:(res)=>{
        console.info(res)
        this.setData({
          goodsList: res.data.data.records
        })
      }
    })
  },
  onLoad(options) {
    wx.request({
      url: 'http://159.75.133.247:8089/store/store/page?currentPage=1&pageSize=100&groupName=zy&busiType=cotegory&subType=level01&dataKey=',
      method:'GET',
      success: (res)=>{
        //把获取到的数据   赋值给categoryList
        console.info(res)
        this.setData({
          categoryList : res.data.data.records
        })
        //加载对应商品
        this.getGoodsList('game')
      }
    })
  },
  changeActive(e){
    console.info(e)
    this.setData({
      activeIndex : e.currentTarget.dataset.index
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})