CREATE DATABASE IF NOT EXISTS sushe;
USE sushe;


DROP TABLE IF EXISTS `superuser`;
CREATE TABLE `superuser` (
  `sid` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(60) NOT NULL,
  `password` VARCHAR(50) NOT NULL COMMENT '超级管理员密码',  
  PRIMARY KEY (`sid`)
) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


INSERT INTO `superuser` (`sid`,`username`,`password`) VALUES (1,'超级管理员','1');



DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(60) NOT NULL,
  `password` VARCHAR(50) NOT NULL COMMENT '管理员密码',  
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


INSERT INTO `user` (`id`,`username`,`password`) VALUES (1,'管理员','1');

DROP TABLE IF EXISTS `room`;
CREATE TABLE `room` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `building`  int(50) NOT NULL COMMENT '房间楼号',
  `room`  int(50) NOT NULL COMMENT '房间号',
  `sex` varchar(2) not NULL ,
  `amount` int(45) not NULL ,
  `expense` float not NULL ,  
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `room`(`id`,`building`,`room`,`sex`,`amount`,`expense`) VALUES(1,18,517,'男',4,'2000');
INSERT INTO `room`(`id`,`building`,`room`,`sex`,`amount`,`expense`) VALUES(2,18,518,'男',4,'2000');
INSERT INTO `room`(`id`,`building`,`room`,`sex`,`amount`,`expense`) VALUES(3,18,519,'男',4,'2000');
INSERT INTO `room`(`id`,`building`,`room`,`sex`,`amount`,`expense`) VALUES(4,17,515,'男',4,'2000');
INSERT INTO `room`(`id`,`building`,`room`,`sex`,`amount`,`expense`) VALUES(5,17,516,'男',4,'2000');

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `studentid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `building`  int(50) NOT NULL COMMENT '房间楼号',
  `room`  int(50) NOT NULL COMMENT '房间号',
  `sex` varchar(2) not NULL ,
  `name` varchar(11) not NULL ,
  `department` varchar(11) not NULL ,  
  PRIMARY KEY (`studentid`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
INSERT INTO `student`(`studentid`,`building`,`room`,`sex`,`name`,`department`) VALUES(1,18,517,'男','杨志杰','计算机系');
INSERT INTO `student`(`studentid`,`building`,`room`,`sex`,`name`,`department`) VALUES(2,18,517,'男','黄亚彬','计算机系');
INSERT INTO `student`(`studentid`,`building`,`room`,`sex`,`name`,`department`) VALUES(3,18,517,'男','秦哲兵','计算机系');
INSERT INTO `student`(`studentid`,`building`,`room`,`sex`,`name`,`department`) VALUES(4,18,517,'男','唐静虎','计算机系');
INSERT INTO `student`(`studentid`,`building`,`room`,`sex`,`name`,`department`) VALUES(5,18,516,'男','吴泽利','计算机系');
INSERT INTO `student`(`studentid`,`building`,`room`,`sex`,`name`,`department`) VALUES(6,18,516,'男','赵子龙','化工学院');


