﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace gaoxiaoss
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{ 
		Program DataConnection =new Program();
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void ButtonlogicClick(object sender, EventArgs e)
		{
			if (textBoxusername.Text != "")
            {
                if (textBoxsecret.Text != "")
                {
                	
                    DataConnection.getConn();
                    string id = textBoxusername.Text.Trim();
                    string pwd = textBoxsecret.Text.Trim();
                    string sql = "select count(*) from [login] where 用户名='" + id + "' and 密码='" + pwd + "'";
                    int state = DataConnection.GetCountInfoBySql(sql);
             
             
                    if (state == 0 || state > 1)
                    {
       					MessageBox.Show("用户名或密码错误！！！"+state);
                    }
                    else
                    {
                        menu f2 = new menu();
                        f2.Show();
                        this.Hide();
                    }
                    DataConnection.CloseConn();
                }
                else
                {
                    MessageBox.Show("密码为空！！！请输入....");
                }
            }
            else
            {
                MessageBox.Show("用户名为空！！！请输入....");
            }
		}
		
		void ButtonresetClick(object sender, EventArgs e)
		{
			textBoxsecret.Text="";
			textBoxusername.Text="";
		}
		
		void TextBoxsecretTextChanged(object sender, EventArgs e)
		{
			textBoxsecret.PasswordChar='*';
		}
		
		
		void TextBoxusernameKeyPress(object sender, KeyPressEventArgs e)
		{
			if(e.KeyChar==(char)Keys.Enter)
				textBoxsecret.Focus();
		}
		
		void TextBoxsecretKeyPress(object sender, KeyPressEventArgs e)
		{
			if(e.KeyChar==(char)Keys.Enter)
				ButtonlogicClick(sender,e);
		}

        private void textBoxusername_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
