// pages/mall/mall.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fetchDataList: [],
    itemObj: {
      // 组id
      // id: null,
      // 组名称
      groupName: '',
      // 花卉分类
       busiType: '',
      // 花语分类
      subType: '',
      // 花卉id
      dataKey: '',
      // 花语名
      dataValue: '',
      // 花语含义
      dataValue2: '',
      // 花语相关
      dataValue3: '',
      // 排序
      dataOrder: ''
    }
  },
  // 获取数据
  getData(){
    //发起请求
    wx.request({
      url: 'http://159.75.133.247:8089/store/store/page?currentPage=1&pageSize=5&groupName=bls',
    method: 'GET',//GET\POST\DELETE\PUT
    success: (res)=>{
    console.log(res)
    console.log(res.data.data.records)
    this.setData({
    goodsList:res.data.data.records
    })
    }
    })
  },
  // 新增数据
  addData() {
    const data = Object.assign(this.data.itemObj, { id: null })
    wx.request({
      url: 'http://159.75.133.247:8089/store/store/add',
      method: 'PUT',
      data: this.data.itemObj,
      success: res => {
        console.log('新增数据成功的回调', res)
        this.getData()
      },
      fail: err => {
        console.log('新增数据失败的回调', err)
      },
      complete: res => {
        console.log('新增数据完成的回调', res)
      }
    })
  },
  // 保存编辑按钮的回调
  saveEdit_btn() {
    const data = this.data.itemObj
    wx.request({
      url: 'http://159.75.133.247:8089/store/store/update',
      method: 'post',
      data: data,
      success: res => {
        console.log('编辑成功的回调', res)
      },
      fail: err => {
        console.log('编辑失败的回调', err)
      }
    })
    this.getData()
    this.clearData()
  },
  // 编辑按钮的回调
  editData(e) {
    console.log(e)
    const itemObj = Object.assign(this.data.itemObj, e.currentTarget.dataset.item)
    console.log('itemObj', itemObj)
    this.setData({
      itemObj
    })
    // this.setData({
    //   id: e.currentTarget.dataset.item.id,
    //   groupName: e.currentTarget.dataset.item.groupName,
    //   busiType: e.currentTarget.dataset.item.busiType,
    //   subType: e.currentTarget.dataset.item.subType,
    //   dataKey: e.currentTarget.dataset.item.dataKey,
    //   dataValue: e.currentTarget.dataset.item.dataValue,
    //   dataValue2: e.currentTarget.dataset.item.dataValue2,
    //   dataValue3: e.currentTarget.dataset.item.dataValue3,
    //   dataOrder: e.currentTarget.dataset.item.dataOrder
    // })
  },
  // 删除按钮的回调
  deleteData(e) {
    const id = e.currentTarget.dataset.id
    wx.request({
      url: 'http://159.75.133.247:8089/store/store/delete',
      method: 'delete',
      data: {
        id: id
      },
      success: res => {
        console.log('删除成功的回调', res), this.getData()
      },
      fail: err => {
        console.log('删除失败的回调', err)
      },
      complete: res => {
        console.log('complete', res)
      }
    })
  },
  // 清空数据
  clearData() {
    this.setData({
      itemObj: {
        // 组id
        // id: null,
        // 组名称
        groupName: '',
        
        busiType: '',
       
        subType: '',
      
        dataKey: '',
        
        dataValue: '',
       
        dataValue2: '',
        
        dataValue3: '',
        
        dataOrder: ''
      }
    })
  },
  changeId(e) {
    // console.log(e)
    this.setData({
      'itemObj.id': e.detail.value
    })
  },
  changeGroupName(e) {
    this.setData({
      'itemObj.groupName': e.detail.value
    })
  },
  changeBusiType(e) {
    this.setData({
      'itemObj.busiType': e.detail.value
    })
  },
  changeSubType(e) {
    this.setData({
      'itemObj.subType': e.detail.value
    })
  },
  changeDataKey(e) {
    this.setData({
      'itemObj.dataKey': e.detail.value
    })
  },
  changeDataValue(e) {
    this.setData({
      'itemObj.dataValue': e.detail.value
    })
  },
  changeDataValue2(e) {
    this.setData({
      'itemObj.dataValue2': e.detail.value
    })
  },
  changeDataValue3(e) {
    this.setData({
      'itemObj.dataValue3': e.detail.value
    })
  },
  changeDataOrder(e) {
    this.setData({
      'itemObj.dataOrder': e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})