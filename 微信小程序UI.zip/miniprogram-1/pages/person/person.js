// pages/person/person.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    content: "花卉榜单", arr:[1,2,3],
    goods: {"name":"月季","price":1111},
    list: [
     '月季',
     '玫瑰',
     '向日葵',
     '蓝铃花',
     '喇叭花',
     '牡丹',
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const goods = {
      ...this.data.goods, 
      price: 550
      }
      //修改数组
      const arr = [this.data.arr,4,5,6]
      //类属性 和要改变的属性名称相同的话:后面部分可以shenglue this.setData({
      content : "heheh", 
      goods ,
       arr
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    console.log('页面下拉刷新成功')
    const list = [
      '希望',
      '幸福',
      '憧憬',
      '祝福',
      '富贵',
    ]
    this.setData({
      list
    })

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    console.log('页面已经到达底部')
    this.data.list.push('1','2','3','4','5',)
    this.setData({
      list: this.data.list
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})