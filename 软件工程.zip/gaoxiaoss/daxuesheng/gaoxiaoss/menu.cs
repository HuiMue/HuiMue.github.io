﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace gaoxiaoss
{
	/// <summary>
	/// Description of menu.
	/// </summary>
	public partial class menu : Form
	{
		Program DataConnection =new Program();
		
		public menu()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			//DataConnection.getConn();
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void 就业率ToolStripMenuItemClick(object sender, EventArgs e)
		{   paneljiuye.Visible=true;
			panelcompany.Visible=false;
			panelprework.Visible=false;
			panelworked.Visible=false;
			panelchange.Visible=false;
			string sql = "select count(*) from student_info";
            int a=DataConnection.GetCountInfoBySql(sql);
            textBoxgradnum.Text = a.ToString();
            sql = "select count(*) from student_info where 就业标志='已就业'";
            int b = DataConnection.GetCountInfoBySql(sql);
            textBoxworkednum.Text = b.ToString();
            sql = "select count(*) from student_info where 就业标志='待就业'";
            textBoxpreworknum.Text = DataConnection.GetCountInfoBySql(sql).ToString();
            float  c =(float) b / a;
            textBoxworkrate.Text = c.ToString();
           comboBoxmajor.Items.Clear();
            sql = "select 专业名称 from department order by  专业编号 asc";
            SqlDataReader dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
                comboBoxmajor.Items.Add(dr["专业名称"]);
            }
            dr.Close();
            comboBoxmajor.Text = "";
            textBoxmajorworkedrate.Text = "";
			
		}
		void ButtoncheckClick(object sender, EventArgs e)
		{ 
			textBoxmajorworkedrate.Text = "";
            if (comboBoxmajor.Text != "")
            {
                string sql = "select count(*) from student_info,department where student_info.专业编号=department.专业编号 and 专业名称='" + comboBoxmajor.Text + "'";
                int a = DataConnection.GetCountInfoBySql(sql);
                sql = "select count(*) from student_info,department where student_info.专业编号=department.专业编号 and 就业标志='已就业' and 专业名称='" + comboBoxmajor.Text + "'";
                int b = DataConnection.GetCountInfoBySql(sql);
                if (a == 0)
                {
                    textBoxmajorworkedrate.Text = "该专业学生人数为0";
                }
                else
                {
                    float c = (float)b / a;
                    textBoxmajorworkedrate.Text = c.ToString();
                }
            }
            else
                MessageBox.Show("专业为空！！！请选择….");
			
		}
		void 修改ToolStripMenuItemClick(object sender, EventArgs e)
		{ panelchange.Visible=true;
		    panelcompany.Visible=false;
			paneljiuye.Visible=false;
			panelprework.Visible=false;
			panelworked.Visible=false;
			
			buttonadd.Visible=false;
			groupBoxchange.Visible=true;
			
			comboBoxMajr.Items.Clear();
			
            comboBoxcomcompany.Items.Clear();
            comboBoxtype.Items.Clear();
            comboBoxschool.Items.Clear();
            radioButtonworked.Checked = false;
            radioButtongirl.Checked = false;
            radioButtonprework.Checked = false;
            radioButtonboy.Checked = false;
           
            string sql = "select  专业名称 from department order by 专业编号 asc";
            
            SqlDataReader dr=DataConnection.GetSqlDataReader(sql);
           
            while (dr.Read())
            {
            	comboBoxMajr.Items.Add(dr["专业名称"].ToString());
            }
            dr.Close();
            
            sql = "select  distinct 用人单位 from profesion_student";
            dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
            	comboBoxcomcompany.Items.Add(dr.GetValue(0).ToString());
            }
            dr.Close();
            sql = "select  类型名称 from dbo.type";
            dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
               comboBoxtype.Items.Add(dr.GetValue(0).ToString());
            }
            dr.Close();
            sql = "select  院系名称 from academy order by 院系编号 asc";
            dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
                comboBoxschool.Items.Add(dr.GetValue(0).ToString());
            }
            dr.Close();
            //while (textBoxid.Text.Trim() == "");
            if(textBoxid.Text!="")
            {
                string id = textBoxid.Text.Trim();
                string sql1 = "select 姓名 from student_info where 学号='" + id + "'";
                textBoxname.Text = DataConnection.GetDataString(sql1);
                sql1 = "select 性别 from student_info where 学号='" + id + "'";
                string s = DataConnection.GetDataString(sql1);
                if (s == "男")
                    radioButtonboy.Checked = true;
                if (s == "女")
                    radioButtongirl.Checked = true;
                sql1 = "select 出生年月 from student_info where 学号='" + id + "'";
                textBoxbirth.Text = DataConnection.GetDataString(sql1);
                sql1 = "select 籍贯 from student_info where 学号='" + id + "'";
                textBoxhome.Text = DataConnection.GetDataString(sql1);
                sql1 = "select 专业名称 from student_info,department where student_info.专业编号=department.专业编号 and 学号='" + id + "'";
                comboBoxMajr.Text = DataConnection.GetDataString(sql1);
                sql1 = "select 院系名称 from student_info,academy where student_info.院系编号=academy.院系编号 and 学号='" + id + "'";
                comboBoxschool.Text = DataConnection.GetDataString(sql1);
                sql1 = "select 就业标志 from student_info where 学号='" + id + "'";
                string s1 = DataConnection.GetDataString(sql1).Trim();
                if (s1 == "待就业")
                {
                   radioButtonprework.Checked = true;
                }
                if (s1 == "已就业")
                {
                    radioButtonworked.Checked = true;
                }
                sql1 = "select 用人单位 from profesion_student,employment  where profesion_student.职业号=employment.职业号 and employment.学号='" + id + "'";
                comboBoxcomcompany.Text = DataConnection.GetDataString(sql1);
                sql1 = "select 类型名称 from type,profesion_student,employment  where type.类型号=profesion_student.类型号 and profesion_student.职业号=employment.职业号 and employment.学号='" + id + "'";
                comboBoxtype.Text = DataConnection.GetDataString(sql1);
            }
            else
                MessageBox.Show("学号为空！！！请输入....");
		}
		void ButtonchangebasedinfoClick(object sender, EventArgs e)		
		{
			if (textBoxid.Text != "")
            {

                string sql = "select 院系编号 from academy where 院系名称='" + comboBoxschool.Text.Trim() + "'";
                string a = DataConnection.GetDataString(sql).Trim();
                sql = "select 专业编号 from department where 专业名称='" + comboBoxMajr.Text.Trim() + "'";

                string b = DataConnection.GetDataString(sql).Trim();
                if (radioButtongirl.Checked == true)
                {

                    sql = "update student_info set 性别='" + radioButtongirl.Text + "' where 学号='" + textBoxid.Text.Trim() + "'";
                    DataConnection.UpdateDate(sql);
                }
                if (radioButtonboy.Checked == true)
                {

                    sql = "update student_info set 性别='" + radioButtonboy.Text + "' where 学号='" + textBoxid.Text.Trim() + "'";
                    DataConnection.UpdateDate(sql);
                }

                sql = "update student_info set 姓名='" + textBoxname.Text.Trim() + "',出生年月='" + textBoxbirth.Text.Trim() + "',籍贯='" + textBoxhome.Text.Trim() + "',专业编号='" + b + "',院系编号='" + a + "' where 学号='" + textBoxid.Text.Trim() + "'";
                DataConnection.UpdateDate(sql);
            }
            else
                MessageBox.Show("学号为空！！！请输入....");
		}
		void ButtonchangejobinfoClick(object sender, EventArgs e)
		{
			if (textBoxid.Text != "")
            {
                string id = textBoxid.Text.Trim();
                if (radioButtonworked.Checked == true)
                {
                    if (comboBoxcomcompany.Text != "")
                    {
                        if (comboBoxtype.Text != "")
                        {
                            string a = "select sum(需求数量) from profesion_student,type where profesion_student.类型号=type.类型号 and profesion_student.用人单位='" + comboBoxcomcompany.Text.Trim() + "'and 类型名称='" + comboBoxtype.Text.Trim() + "'";
                            int b = DataConnection.GetCountInfoBySql(a);
                            a = "select sum(聘用数量) from profesion_student,type where profesion_student.类型号=type.类型号 and profesion_student.用人单位='" + comboBoxcomcompany.Text.Trim() + "' and 类型名称='" + comboBoxtype.Text.Trim() + "'";
                            int c = DataConnection.GetCountInfoBySql(a);
                            if (c < b)
                            {
                                string sql = "update student_info set 就业标志 = '已就业' where 学号='" + id + "'";
                                DataConnection.UpdateDate(sql);

                                sql = "select 学号 from employment where 学号='" + id + "'";
                                if (DataConnection.GetCountInfoBySql(sql) == 0)
                                {
                                    sql = "insert into employment(学号)values ('" + id + "')";
                                    DataConnection.UpdateDate(sql);
                                }
                                string s = "select 职业号 from profesion_student,type where profesion_student.类型号 =type.类型号 and profesion_student.用人单位='" +comboBoxcomcompany.Text.Trim() + "' and 类型名称 ='" + comboBoxtype.Text.Trim() + "'";
                                s = DataConnection.GetDataString(s).Trim();
                                sql = "select count(*) from employment where 职业号='" + s + "'";
                                int d = DataConnection.GetCountInfoBySql(sql);
                                sql = "update profesion_student set 聘用数量=" + d + " where 职业号='" + s + "'";
                                DataConnection.UpdateDate(sql);
                                sql = "update employment set 职业号='" + s + "' where 学号='" + id + "'";
                                DataConnection.UpdateDate(sql);
                            }
                            else
                                MessageBox.Show("公司聘用数量已达上线！！！");

                        }
                        else
                            MessageBox.Show("类型号为空！！！请选择....");
                    }
                    else
                    {
                        MessageBox.Show("用人单位为空！！！请选择....\n否则，将就业情况修改为待就业！！！");
                        radioButtonprework.Checked = true;
                        string s = "update student_info set 就业标志='待就业' where 学号='" + id + "'";
                        DataConnection.UpdateDate(s);
                        string sql = "select 学号 from employment where 学号='" + id + "'";
                        int h = DataConnection.GetCountInfoBySql(sql);
                        s = "select 职业号 from employment where 学号='" + id+"'";
                        s = DataConnection.GetDataString(s).Trim();
                        if (DataConnection.GetCountInfoBySql(sql) > 0)
                        {
                            sql= "delete from employment where 学号= '" + id + "'";
                            DataConnection.UpdateDate(sql);

                        }
                        sql = "select count(*) from employment where 职业号='" + s + "'";
                        int d = DataConnection.GetCountInfoBySql(sql);
                        sql = "update profesion_student set 聘用数量 ="+d+"where 职业号='"+s+"'";
                        DataConnection.UpdateDate(sql);
                    }
                }
                else
                    MessageBox.Show("学号为空！！！请输入....");
            }
		}
		void TextBox2TextChanged(object sender, EventArgs e)
		{
			
		}
		
		void PanelchangePaint(object sender, PaintEventArgs e)
		{
			
		}
		
		void 退出ToolStripMenuItemClick(object sender, EventArgs e)
		{
			Application.Exit();
		}
		
		void 添加ToolStripMenuItemClick(object sender, EventArgs e)
		{
			panelcompany.Visible=false;
			paneljiuye.Visible=false;
			panelprework.Visible=false;
			panelworked.Visible=false;
			panelchange.Visible=true;
			groupBoxchange.Visible=false;
			buttonadd.Visible=true;
			string sql = "select  专业名称 from department order by 专业编号 asc";
            
            SqlDataReader dr=DataConnection.GetSqlDataReader(sql);
           
            while (dr.Read())
            {
            	comboBoxMajr.Items.Add(dr["专业名称"].ToString());
            }
            dr.Close();
            sql = "select  distinct 用人单位 from profesion_student";
            dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
            	comboBoxcomcompany.Items.Add(dr.GetValue(0).ToString());
            }
            dr.Close();
            sql = "select  类型名称 from dbo.type";
            dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
               comboBoxtype.Items.Add(dr.GetValue(0).ToString());
            }
            dr.Close();
            sql = "select  院系名称 from academy order by 院系编号 asc";
            dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
                comboBoxschool.Items.Add(dr.GetValue(0).ToString());
            }
            dr.Close();
		}
		
		void 已就业信息ToolStripMenuItemClick(object sender, EventArgs e)
		{  
			panelcompany.Visible=false;
			paneljiuye.Visible=false;
			panelprework.Visible=false;
			panelchange.Visible=false;
			panelworked.Visible=true;
			comboBoxcollege.Items.Clear();
            comboBoxmajo.Items.Clear();
            comboBoxcollege.Text = "";
            comboBoxmajo.Text = "";
            string sql = "select 专业名称 from department order by 专业编号 asc ";
            SqlDataReader dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
                comboBoxmajo.Items.Add(dr["专业名称"]);
            }
            dr.Close();
            sql = "select 院系名称 from academy order by 院系编号 asc";
            dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
               comboBoxcollege.Items.Add(dr["院系名称"]);
            } 
            dr.Close();
		}
		void ButtoncollegeClick(object sender, EventArgs e)
		{comboBoxmajo.Text="";
			if (comboBoxcollege.Text != "")
            {
               string s = "select c5.学号,姓名,出生年月,籍贯,院系名称,专业名称,就业标志,用人单位,类型名称 from type right join (select c4.学号,姓名,出生年月,就业标志,籍贯,院系名称,专业名称,c4.职业号,类型号,用人单位 from profesion_student right join (select c3.学号,姓名,出生年月,就业标志,籍贯,院系名称,专业名称,职业号 from dbo.employment right join (select 学号,姓名,出生年月,就业标志,籍贯,院系名称,专业名称 from department join (select 学号,姓名,出生年月,就业标志,籍贯,院系名称,专业编号  from academy join (select 学号,姓名,出生年月,院系编号,籍贯 ,就业标志,专业编号 from student_info where 就业标志='已就业')c1 on academy.院系编号=c1.院系编号)c2 on department.专业编号=c2.专业编号)c3 on employment.学号=c3.学号)c4 on profesion_student.职业号=c4.职业号) c5 on type.类型号=c5.类型号 where 院系名称='"+ comboBoxcollege.Text.Trim() + "'order by c5.学号";

               dataGridViewworked.DataSource = DataConnection.GetDataSuoce(s).Tables[0];
            }
            else
                MessageBox.Show("院系名称为空！！！请选择....");
			
		}
		void ButtonmajorClick(object sender, EventArgs e)
		{
			comboBoxcollege.Text="";
			 if (comboBoxmajo.Text != "")
            {
                string s = "select c5.学号,姓名,出生年月,籍贯,院系名称,专业名称,就业标志,用人单位,类型名称 from type right join (select c4.学号,姓名,出生年月,就业标志,籍贯,院系名称,专业名称,c4.职业号,类型号,用人单位 from profesion_student right join (select c3.学号,姓名,出生年月,就业标志,籍贯,院系名称,专业名称,职业号 from dbo.employment right join (select c2.学号,姓名,出生年月,就业标志,籍贯,院系名称,专业名称 from department join (select c1.学号,姓名,出生年月,就业标志,籍贯,院系名称,专业编号  from academy join (select 学号,姓名,出生年月,院系编号,籍贯 ,就业标志,专业编号 from student_info where 就业标志='已就业')c1 on academy.院系编号=c1.院系编号)c2 on department.专业编号=c2.专业编号)c3 on employment.学号=c3.学号)c4 on profesion_student.职业号=c4.职业号) c5 on type.类型号=c5.类型号 where 专业名称='" + comboBoxmajo.Text.Trim() + "'order by c5.学号";
                dataGridViewworked.DataSource = DataConnection.GetDataSuoce(s).Tables[0];
            }

            else
                MessageBox.Show("专业名称为空！！！请选择....");
		}
		void 未就业信息ToolStripMenuItemClick(object sender, EventArgs e)
		{
			panelcompany.Visible=false;
			paneljiuye.Visible=false;
			panelworked.Visible=false;
			panelchange.Visible=false;
			panelprework.Visible=true;
			comboBoxprecollege.Items.Clear();
            comboBoxmajor1.Items.Clear();
            comboBoxprecollege.Text = "";
            comboBoxmajor1.Text = "";
            string sql = "select 专业名称 from department order by 专业编号 asc";
            SqlDataReader dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {

                comboBoxmajor1.Items.Add(dr["专业名称"]);
            }
            dr.Close();
            sql = "select 院系名称 from academy order by 院系编号 asc";
            dr = DataConnection.GetSqlDataReader(sql);
            while (dr.Read())
            {
                comboBoxprecollege.Items.Add(dr["院系名称"]);

            }
            dr.Close();
		}
		
		void Buttoncollege1Click(object sender, EventArgs e)
		{
			comboBoxmajor1.Text="";
			 if ( comboBoxprecollege.Text != "")
            {
                string sql = "select student_info.学号,姓名,出生年月,籍贯,院系名称,专业名称,就业标志 from student_info,academy,department where student_info.院系编号=academy.院系编号 and student_info.专业编号=department.专业编号  and 就业标志='待就业' and 院系名称='" + comboBoxprecollege.Text.Trim() + "'order by student_info.学号";
                dataGridViewprework.DataSource = DataConnection.GetDataSuoce(sql).Tables[0];
            }

            else
                MessageBox.Show("院系名称为空！！！请选择....");
		}
		void Buttonmajor1Click(object sender, EventArgs e)
		{
			comboBoxprecollege.Text="";
			if (comboBoxmajor1.Text != "")
            {

                string sql = "select student_info.学号,姓名,出生年月,籍贯,院系名称,专业名称,就业标志 from student_info,academy,department where student_info.院系编号=academy.院系编号 and student_info.专业编号=department.专业编号  and 就业标志='待就业' and 专业名称='" + comboBoxmajor1.Text.Trim() + "'order by student_info.学号";
                dataGridViewprework.DataSource = DataConnection.GetDataSuoce(sql).Tables[0];
            }
            else
                MessageBox.Show("专业名称为空！！！请选择....");
		}
		
		void 公司信息ToolStripMenuItemClick(object sender, EventArgs e)
		{
			paneljiuye.Visible=false;
			panelworked.Visible=false;
			panelchange.Visible=false;
			panelprework.Visible=false;
			panelcompany.Visible=true;
		
			//dataGridViewcompany.RowHeadersVisible=false;
			//dataGridViewcompany.AutoGenerateColumns=false;
			string sql = "select 用人单位,职业号,需求数量,聘用数量 from profesion_student,type where type.类型号=profesion_student.类型号";
			dataGridViewcompany.DataSource=DataConnection.GetDataSuoce(sql).Tables[0];
		}
		
		void 查询ToolStripMenuItemClick(object sender, EventArgs e)
		{
		}
	

		
		void MenuLoad(object sender, EventArgs e)
		{
			DataConnection.getConn();
		}
		
		
		void DataGridViewworkedCellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			
		}
		
		void LabelmajorrateClick(object sender, EventArgs e)
		{
			
		}
		
		void PaneljiuyePaint(object sender, PaintEventArgs e)
		{
			
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			string  sql = "insert into employment(学号)values ('" +textBoxid.Text + "')";
            DataConnection.UpdateDate(sql);
            string sex,major;
            if(radioButtonboy.Checked==true)
            	sex="男";
            		else sex="女";
            if(radioButtonprework.Checked==true)
              major="待就业";
            else major="已就业";
            if(comboBoxMajr.Text!="")
            {
            		sql="select 所属学院 from department where 专业名称='" + comboBoxMajr.Text.Trim() + "'";
            		string academy=DataConnection.GetDataString(sql).Trim();
            	if(academy!=comboBoxschool.Text.Trim())
            		{
            			
            			MessageBox.Show("该专业不属于该学院，重新选择"+academy+comboBoxschool.Text);
            			comboBoxschool.Text="";
            		}
            		else 
            		{
		            sql = "select 院系编号 from academy where 院系名称='" + comboBoxschool.Text.Trim() + "'";
		            string academynum = DataConnection.GetDataString(sql).Trim();
		            sql = "select 专业编号 from department where 专业名称='" + comboBoxMajr.Text.Trim() + "'";
		
		            string majornum = DataConnection.GetDataString(sql).Trim();
		 			sql = "insert into student_info(姓名,性别,出生年月,籍贯,专业编号,院系编号,就业标志,学号) values ('"+textBoxname.Text+"','"+sex+"','"+textBoxbirth.Text+"','"+textBoxhome.Text+"','"+majornum+"','"+academynum+"','"+major+"','"+textBoxid.Text+"')";
		          	DataConnection.UpdateDate(sql);
		          	if(major=="已就业")
		          	{
		          		
		          		sql="select 类型号 from type where 类型名称='"+comboBoxtype.Text+"'";
		          		string typenum = DataConnection.GetDataString(sql).Trim();
		          		sql="update profesion_student set 需求数量-=1 where 用人单位='"+comboBoxcomcompany+"' and 职业号='"+typenum+"'";
		          	}
		          	MessageBox.Show("添加成功");
            		}
            }
            else MessageBox.Show("专业选项为空！");
            
		}
		
		
		void ComboBoxtypeSelectedIndexChanged(object sender, EventArgs e)
		{
			
		}
		
		void PanelworkedPaint(object sender, PaintEventArgs e)
		{
			
		}
		
		void GroupBox2Enter(object sender, EventArgs e)
		{
			
		}
		
		void RadioButtongirlCheckedChanged(object sender, EventArgs e)
		{
			
		}
		
		void DataGridViewcompanyCellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			
		}
		
		void PanelpreworkPaint(object sender, PaintEventArgs e)
		{
			
		}
		
		void DataGridViewpreworkCellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			
		}
		
		void ComboBoxmajor1SelectedIndexChanged(object sender, EventArgs e)
		{
			
		}
		
		void ComboBoxprecollegeSelectedIndexChanged(object sender, EventArgs e)
		{
			
		}
		
		void TextBoxidKeyPress(object sender, KeyPressEventArgs e)
		{
			if(e.KeyChar==(char)Keys.Enter)
			{
				修改ToolStripMenuItemClick(sender,e);
			}
		}

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
