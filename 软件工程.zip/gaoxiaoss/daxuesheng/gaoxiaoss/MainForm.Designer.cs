﻿
namespace gaoxiaoss
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonlogic = new System.Windows.Forms.Button();
            this.buttonreset = new System.Windows.Forms.Button();
            this.textBoxusername = new System.Windows.Forms.TextBox();
            this.textBoxsecret = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(116, 62);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(286, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "大学生就业管理系统登陆界面";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(135, 141);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "用户名：";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label3.Location = new System.Drawing.Point(134, 202);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "密码：";
            // 
            // buttonlogic
            // 
            this.buttonlogic.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonlogic.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttonlogic.Location = new System.Drawing.Point(127, 281);
            this.buttonlogic.Margin = new System.Windows.Forms.Padding(2);
            this.buttonlogic.Name = "buttonlogic";
            this.buttonlogic.Size = new System.Drawing.Size(98, 30);
            this.buttonlogic.TabIndex = 3;
            this.buttonlogic.Text = "登录";
            this.buttonlogic.UseVisualStyleBackColor = true;
            this.buttonlogic.Click += new System.EventHandler(this.ButtonlogicClick);
            // 
            // buttonreset
            // 
            this.buttonreset.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonreset.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttonreset.Location = new System.Drawing.Point(271, 281);
            this.buttonreset.Margin = new System.Windows.Forms.Padding(2);
            this.buttonreset.Name = "buttonreset";
            this.buttonreset.Size = new System.Drawing.Size(98, 30);
            this.buttonreset.TabIndex = 3;
            this.buttonreset.Text = "重置";
            this.buttonreset.UseVisualStyleBackColor = true;
            this.buttonreset.Click += new System.EventHandler(this.ButtonresetClick);
            // 
            // textBoxusername
            // 
            this.textBoxusername.Location = new System.Drawing.Point(204, 142);
            this.textBoxusername.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxusername.Name = "textBoxusername";
            this.textBoxusername.Size = new System.Drawing.Size(153, 21);
            this.textBoxusername.TabIndex = 4;
            this.textBoxusername.TextChanged += new System.EventHandler(this.textBoxusername_TextChanged);
            this.textBoxusername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxusernameKeyPress);
            // 
            // textBoxsecret
            // 
            this.textBoxsecret.Location = new System.Drawing.Point(204, 202);
            this.textBoxsecret.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxsecret.Name = "textBoxsecret";
            this.textBoxsecret.Size = new System.Drawing.Size(153, 21);
            this.textBoxsecret.TabIndex = 4;
            this.textBoxsecret.TextChanged += new System.EventHandler(this.TextBoxsecretTextChanged);
            this.textBoxsecret.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxsecretKeyPress);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 384);
            this.Controls.Add(this.textBoxsecret);
            this.Controls.Add(this.textBoxusername);
            this.Controls.Add(this.buttonreset);
            this.Controls.Add(this.buttonlogic);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MainForm";
            this.Text = "高校学生就业管理系统";
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.TextBox textBoxsecret;
		private System.Windows.Forms.TextBox textBoxusername;
		private System.Windows.Forms.Button buttonreset;
		private System.Windows.Forms.Button buttonlogic;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
	}
}
